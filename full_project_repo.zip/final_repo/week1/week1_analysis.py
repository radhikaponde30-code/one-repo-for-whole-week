"""
Week 1 Task - Data Acquisition, Cleaning, and EDA
Dataset: Breast Cancer Wisconsin (Diagnostic) Data Set
Source: UCI Machine Learning Repository, distributed via scikit-learn
        (sklearn.datasets.load_breast_cancer)
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_breast_cancer

np.random.seed(42)
sns.set_theme(style="whitegrid")

# -----------------------------------------------------------------------
# 1. DATA ACQUISITION
# -----------------------------------------------------------------------
data = load_breast_cancer(as_frame=True)
df = data.frame.copy()
df['diagnosis'] = df['target'].map({0: 'malignant', 1: 'benign'})
df = df.drop(columns=['target'])

print("Original shape:", df.shape)
df.to_csv('breast_cancer_original.csv', index=False)

# -----------------------------------------------------------------------
# 2. SIMULATE REAL-WORLD MESSINESS (documented, for demonstration purposes)
#    The as-distributed dataset is already clean (no missing values,
#    no duplicates). To faithfully practice the cleaning workflow this
#    task requires, we deliberately inject a controlled amount of
#    missingness and duplicate rows into a working copy. This step is
#    disclosed clearly in the report; all cleaning below is performed on
#    this "raw" copy.
# -----------------------------------------------------------------------
raw = df.copy()

# inject ~4% missing values at random into a subset of numeric columns
cols_to_null = ['mean radius', 'mean texture', 'mean smoothness',
                 'worst area', 'worst concavity', 'symmetry error']
for col in cols_to_null:
    mask = np.random.rand(len(raw)) < 0.04
    raw.loc[mask, col] = np.nan

# duplicate 12 random rows to simulate accidental double-entry
dupe_idx = np.random.choice(raw.index, size=12, replace=False)
raw = pd.concat([raw, raw.loc[dupe_idx]], ignore_index=True)

# introduce a formatting inconsistency in the categorical column (mixed case)
mixed_mask = np.random.rand(len(raw)) < 0.15
raw.loc[mixed_mask, 'diagnosis'] = raw.loc[mixed_mask, 'diagnosis'].str.upper()

# a couple of numeric values stored as strings with stray whitespace
raw['mean area'] = raw['mean area'].astype(object)
str_idx = np.random.choice(raw.index, size=5, replace=False)
raw.loc[str_idx, 'mean area'] = raw.loc[str_idx, 'mean area'].apply(lambda v: f" {v} ")

raw.to_csv('breast_cancer_raw.csv', index=False)
print("Raw (messy) shape:", raw.shape)

# -----------------------------------------------------------------------
# 3. DATA CLEANING
# -----------------------------------------------------------------------
clean = raw.copy()

# 3a. Fix dtypes: strip whitespace / coerce numeric-looking strings back to float
clean['mean area'] = pd.to_numeric(
    clean['mean area'].astype(str).str.strip(), errors='coerce'
)

# 3b. Standardise categorical text
clean['diagnosis'] = clean['diagnosis'].str.strip().str.lower()

# 3c. Remove exact duplicate rows
n_before = len(clean)
clean = clean.drop_duplicates()
n_after = len(clean)
print(f"Removed {n_before - n_after} duplicate rows")

# 3d. Handle missing values
missing_summary_before = clean.isna().sum()
missing_summary_before = missing_summary_before[missing_summary_before > 0]
print("\nMissing values before imputation:\n", missing_summary_before)

numeric_cols = clean.select_dtypes(include=[np.number]).columns
# Median imputation chosen over mean because several features (e.g. area,
# concavity) are right-skewed, and the median is more robust to outliers.
for col in numeric_cols:
    if clean[col].isna().sum() > 0:
        clean[col] = clean[col].fillna(clean[col].median())

assert clean.isna().sum().sum() == 0, "Missing values remain after imputation"

clean.to_csv('breast_cancer_clean.csv', index=False)
print("\nFinal cleaned shape:", clean.shape)

# -----------------------------------------------------------------------
# 4. EXPLORATORY DATA ANALYSIS
# -----------------------------------------------------------------------
summary_stats = clean.describe().T
summary_stats.to_csv('summary_statistics.csv')
print("\nSummary statistics saved.")

print("\nClass balance:\n", clean['diagnosis'].value_counts())

# --- Visualization 1: Missing values heatmap (on the RAW data, pre-clean) ---
plt.figure(figsize=(10, 5))
sns.heatmap(raw.drop(columns=['diagnosis']).apply(pd.to_numeric, errors='coerce').isna(),
            cbar=False, cmap="rocket_r", yticklabels=False)
plt.title("Missing Value Pattern in Raw Data (before cleaning)")
plt.xlabel("Feature")
plt.xticks(rotation=75, ha='right', fontsize=7)
plt.tight_layout()
plt.savefig('viz1_missing_values.png', dpi=150)
plt.close()

# --- Visualization 2: Correlation heatmap of key mean-value features ---
key_cols = ['mean radius', 'mean texture', 'mean perimeter', 'mean area',
            'mean smoothness', 'mean compactness', 'mean concavity',
            'mean concave points', 'mean symmetry', 'mean fractal dimension']
plt.figure(figsize=(10, 8))
corr = clean[key_cols].corr()
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", square=True,
            annot_kws={"size": 7}, cbar_kws={"shrink": 0.8})
plt.title("Correlation Matrix - Mean Tumor Features")
plt.xticks(rotation=45, ha='right', fontsize=8)
plt.yticks(fontsize=8)
plt.tight_layout()
plt.savefig('viz2_correlation_heatmap.png', dpi=150)
plt.close()

# --- Visualization 3: Distribution of mean radius by diagnosis (histogram) ---
plt.figure(figsize=(8, 5))
sns.histplot(data=clean, x='mean radius', hue='diagnosis', kde=True,
             element='step', palette={'malignant': '#d62728', 'benign': '#2ca02c'})
plt.title("Distribution of Mean Tumor Radius by Diagnosis")
plt.xlabel("Mean Radius")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig('viz3_radius_histogram.png', dpi=150)
plt.close()

# --- Visualization 4: Boxplot of worst area by diagnosis (outlier check) ---
plt.figure(figsize=(7, 5))
sns.boxplot(data=clean, x='diagnosis', y='worst area',
            hue='diagnosis', palette={'malignant': '#d62728', 'benign': '#2ca02c'}, legend=False)
plt.title("Worst Area by Diagnosis (Outlier Detection)")
plt.xlabel("Diagnosis")
plt.ylabel("Worst Area")
plt.tight_layout()
plt.savefig('viz4_worst_area_boxplot.png', dpi=150)
plt.close()

# --- Visualization 5: Scatter plot - mean radius vs mean concavity ---
plt.figure(figsize=(7, 5))
sns.scatterplot(data=clean, x='mean radius', y='mean concavity', hue='diagnosis',
                 palette={'malignant': '#d62728', 'benign': '#2ca02c'}, alpha=0.7)
plt.title("Mean Radius vs Mean Concavity")
plt.xlabel("Mean Radius")
plt.ylabel("Mean Concavity")
plt.tight_layout()
plt.savefig('viz5_scatter_radius_concavity.png', dpi=150)
plt.close()

print("\nAll visualizations saved.")

# -----------------------------------------------------------------------
# 5. KEY INSIGHTS (printed for reference / documentation)
# -----------------------------------------------------------------------
insights = []
insights.append(f"Dataset contains {clean.shape[0]} patient records and {clean.shape[1]-1} numeric features after cleaning.")
malignant_pct = (clean['diagnosis'] == 'malignant').mean() * 100
insights.append(f"{malignant_pct:.1f}% of records are malignant, {100-malignant_pct:.1f}% benign.")
top_corr = corr.abs().unstack().sort_values(ascending=False)
top_corr = top_corr[top_corr < 1].drop_duplicates()
insights.append(f"Strongest correlation among mean features: {top_corr.index[0]} = {top_corr.iloc[0]:.2f}")
mean_radius_malignant = clean.loc[clean.diagnosis=='malignant', 'mean radius'].mean()
mean_radius_benign = clean.loc[clean.diagnosis=='benign', 'mean radius'].mean()
insights.append(f"Average mean radius: malignant={mean_radius_malignant:.2f}, benign={mean_radius_benign:.2f}")

with open('insights.txt', 'w') as f:
    f.write('\n'.join(insights))

print("\nINSIGHTS:")
for i in insights:
    print("-", i)
