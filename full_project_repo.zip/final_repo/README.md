# Data Science Internship Project — Car Features & MSRP

A five-week, end-to-end data science project on a real-world vehicle
listings dataset (11,914 raw / 11,199 cleaned rows), covering the full
lifecycle from data cleaning through machine learning to strategic
business reporting.

## Project Structure

```
week1/  Data Acquisition, Cleaning & Exploratory Data Analysis
week2/  Advanced Data Visualization & Storytelling
week3/  Statistical Analysis & Hypothesis Testing
week4/  Machine Learning Model Development & Evaluation
week5/  Comprehensive Capstone Report & Strategic Recommendations
```

Each week folder contains that week's Python script(s), supporting data
files, and the corresponding Word report submitted for that week.

## Headline Finding

Across three independent methods — visual storytelling (Week 2),
statistical hypothesis testing (Week 3, R² = 0.44), and machine learning
feature importance (Week 4) — **engine horsepower is consistently the
strongest driver of vehicle price**, ahead of vehicle size, brand, or
fuel economy.

## Key Results by Week

| Week | Key Result |
|---|---|
| 1 | Cleaned 11,914 → 11,199 rows; removed 715 duplicates; documented missing-value strategy per field |
| 2 | Six-chart data story showing price trends, brand positioning, and the efficiency/performance trade-off |
| 3 | 4 hypotheses tested (t-test, ANOVA, chi-square, regression), all significant at p < 0.0001 |
| 4 | Decision Tree classifier: 91.4% accuracy, 0.969 ROC-AUC predicting "Luxury" vehicle status from specs |
| 5 | Synthesis report with 5 strategic recommendations for pricing, catalog automation, and data quality |

## How to Run

```bash
pip install pandas numpy scipy scikit-learn seaborn matplotlib
python week1/week1_analysis.py
python week2/week2_build_visuals.py
python week3/week3_analysis.py
python week4/week4_analysis.py
```

## Full Reports

See each week's `.docx` file for full methodology, visualizations, and
discussion. `week5/Week5_Capstone_Report.docx` is the final synthesis
report integrating all four prior weeks into strategic recommendations.
