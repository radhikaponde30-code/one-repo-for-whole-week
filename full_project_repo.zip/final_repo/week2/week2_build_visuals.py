"""
Week 2 Task - Advanced Data Visualization and Storytelling
Dataset: Car Features and MSRP (cleaned in Week 1)
Narrative: "The Price of Power" - what drives vehicle value in the
US new-car market, and what it means for shoppers, automakers, and analysts.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns

df = pd.read_csv('cars_clean.csv')

sns.set_theme(style="whitegrid", font_scale=1.0)
PALETTE = {"accent": "#2E86AB", "warn": "#D64545", "neutral": "#6C757D",
           "gold": "#E8A33D", "green": "#4C956C"}
plt.rcParams['axes.titleweight'] = 'bold'
plt.rcParams['axes.titlesize'] = 13
plt.rcParams['figure.dpi'] = 150

# Focus the narrative on realistic mainstream-to-premium pricing;
# a small number of exotic outliers (>$300k) are excluded from most
# visuals to keep charts readable, but disclosed explicitly in the report.
core = df[df['msrp'] <= 300000].copy()
print("Core analysis set:", core.shape, f"({len(df)-len(core)} exotic outliers excluded from most charts)")

# -----------------------------------------------------------------------
# VIZ 1 — Market Overview: vehicle count by size and style (stacked bar)
# Purpose: orient the reader to what's actually in the market before
# diving into price drivers.
# -----------------------------------------------------------------------
pivot = core.pivot_table(index='vehicle_style', columns='vehicle_size',
                          values='make', aggfunc='count', fill_value=0)
pivot = pivot.loc[pivot.sum(axis=1).sort_values(ascending=True).index]
pivot = pivot[['Compact', 'Midsize', 'Large']]

fig, ax = plt.subplots(figsize=(9, 7))
colors = [PALETTE['accent'], PALETTE['gold'], PALETTE['warn']]
pivot.plot(kind='barh', stacked=True, ax=ax, color=colors, edgecolor='white', linewidth=0.5)
ax.set_title("What's Actually on the Lot: Vehicle Styles by Size Class")
ax.set_xlabel("Number of Listings")
ax.set_ylabel("")
ax.legend(title="Vehicle Size", loc='lower right', frameon=True)
sns.despine(left=True, bottom=True)
plt.tight_layout()
plt.savefig('viz1_market_overview.png', dpi=150)
plt.close()

# -----------------------------------------------------------------------
# VIZ 2 — Price trend over time (median MSRP by year, with IQR band)
# Purpose: establish the time dimension of the story - is the market
# getting more expensive?
# -----------------------------------------------------------------------
yearly = core[core['year'] >= 2001].groupby('year')['msrp'].agg(
    median='median', q25=lambda s: s.quantile(0.25), q75=lambda s: s.quantile(0.75)
).reset_index()
# Note: model years before 2001 show a sharp, implausible drop in MSRP
# (median ~$2,000-2,900 for 1990-2000 vs. ~$22,500+ from 2001 onward),
# which is inconsistent with real-world pricing and most likely a data
# artifact in the source file rather than a genuine market trend. Those
# years are excluded from this chart and the discrepancy is flagged in
# the report rather than silently smoothed over.

fig, ax = plt.subplots(figsize=(9, 5.5))
ax.fill_between(yearly['year'], yearly['q25'], yearly['q75'],
                 color=PALETTE['accent'], alpha=0.18, label='Interquartile range (25th–75th pct)')
ax.plot(yearly['year'], yearly['median'], color=PALETTE['accent'], linewidth=2.5,
        marker='o', markersize=4, label='Median MSRP')
ax.set_title("New-Vehicle Prices Have Risen Steadily Since 2001")
ax.set_xlabel("Model Year")
ax.set_ylabel("MSRP (USD)")
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
ax.legend(loc='upper left', frameon=True)
sns.despine()
plt.tight_layout()
plt.savefig('viz2_price_trend.png', dpi=150)
plt.close()

# -----------------------------------------------------------------------
# VIZ 3 — Bubble chart: HP vs MSRP, bubble size = popularity, color = size class
# Purpose: the core "price of power" relationship, with a third and
# fourth dimension (popularity, vehicle size) layered in.
# -----------------------------------------------------------------------
sample = core.sample(n=min(2500, len(core)), random_state=42)
fig, ax = plt.subplots(figsize=(9, 6.5))
size_colors = {'Compact': PALETTE['accent'], 'Midsize': PALETTE['gold'], 'Large': PALETTE['warn']}
for size_cls, color in size_colors.items():
    sub = sample[sample['vehicle_size'] == size_cls]
    ax.scatter(sub['engine_hp'], sub['msrp'], s=sub['popularity'] / 15 + 8,
               color=color, alpha=0.4, edgecolor='none', label=size_cls)
ax.set_title("Horsepower Drives Price — But Popularity Adds Nuance")
ax.set_xlabel("Engine Horsepower")
ax.set_ylabel("MSRP (USD)")
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
leg = ax.legend(title="Vehicle Size\n(bubble size = popularity)", loc='upper left', frameon=True)
sns.despine()
plt.tight_layout()
plt.savefig('viz3_bubble_hp_price.png', dpi=150)
plt.close()

# -----------------------------------------------------------------------
# VIZ 4 — Efficiency vs. price trade-off (scatter + trend, by fuel type)
# Purpose: shift the narrative to a second tension in the market -
# efficiency vs cost - relevant to both consumers and regulators.
# -----------------------------------------------------------------------
top_fuels = core['engine_fuel_type'].value_counts().head(4).index
fuel_sample = core[core['engine_fuel_type'].isin(top_fuels) & (core['city_mpg'] < 60)]
fig, ax = plt.subplots(figsize=(9, 6))
sns.scatterplot(data=fuel_sample.sample(n=min(2500, len(fuel_sample)), random_state=1),
                 x='city_mpg', y='msrp', hue='engine_fuel_type', alpha=0.45, s=25,
                 palette='Set2', ax=ax, edgecolor='none')
ax.set_title("The Efficiency Trade-Off: City MPG vs. Price by Fuel Type")
ax.set_xlabel("City MPG")
ax.set_ylabel("MSRP (USD)")
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
ax.legend(title="Engine Fuel Type", loc='upper right', frameon=True, fontsize=8)
sns.despine()
plt.tight_layout()
plt.savefig('viz4_efficiency_tradeoff.png', dpi=150)
plt.close()

# -----------------------------------------------------------------------
# VIZ 5 — Manufacturer positioning heatmap (avg MSRP by make x vehicle size)
# Purpose: zoom into brand-level strategy - who plays in which segment,
# and at what price point.
# -----------------------------------------------------------------------
top_makes = core['make'].value_counts().head(15).index
heat_data = core[core['make'].isin(top_makes)].pivot_table(
    index='make', columns='vehicle_size', values='msrp', aggfunc='median'
)
heat_data = heat_data[['Compact', 'Midsize', 'Large']]
heat_data = heat_data.loc[heat_data.mean(axis=1).sort_values(ascending=False).index]

fig, ax = plt.subplots(figsize=(7, 8))
sns.heatmap(heat_data, annot=True, fmt=",.0f", cmap="YlOrRd", ax=ax,
            cbar_kws={'label': 'Median MSRP (USD)', 'shrink': 0.7}, linewidths=0.5)
ax.set_title("Brand Positioning: Median Price by Manufacturer & Size Class")
ax.set_xlabel("Vehicle Size")
ax.set_ylabel("")
plt.tight_layout()
plt.savefig('viz5_brand_heatmap.png', dpi=150)
plt.close()

# -----------------------------------------------------------------------
# VIZ 6 — Violin plot: MSRP distribution by transmission type
# Purpose: closes the story on a more subtle finding - transmission
# type as a proxy for vehicle character (performance vs. economy).
# -----------------------------------------------------------------------
trans_top = core['transmission_type'].value_counts().head(4).index
trans_data = core[core['transmission_type'].isin(trans_top)]
fig, ax = plt.subplots(figsize=(9, 6))
sns.violinplot(data=trans_data, x='transmission_type', y='msrp', hue='transmission_type',
               palette='Set2', ax=ax, cut=0, inner='quartile', legend=False)
ax.set_title("Transmission Type as a Signal of Vehicle Character and Price")
ax.set_xlabel("Transmission Type")
ax.set_ylabel("MSRP (USD)")
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
sns.despine()
plt.tight_layout()
plt.savefig('viz6_transmission_violin.png', dpi=150)
plt.close()

print("All 6 visualizations saved.")

# -----------------------------------------------------------------------
# Numbers referenced in the narrative
# -----------------------------------------------------------------------
stats = {}
stats['median_2001'] = core.loc[core.year == 2001, 'msrp'].median()
stats['median_2016'] = core.loc[core.year == 2016, 'msrp'].median()
stats['hp_price_corr'] = core['engine_hp'].corr(core['msrp'])
stats['mpg_price_corr'] = core['city_mpg'].corr(core['msrp'])
stats['manual_median'] = core.loc[core.transmission_type == 'MANUAL', 'msrp'].median()
stats['auto_median'] = core.loc[core.transmission_type == 'AUTOMATIC', 'msrp'].median()
top_brand = heat_data.mean(axis=1).idxmax()
stats['top_brand'] = top_brand
stats['top_brand_avg'] = heat_data.mean(axis=1).max()
for k, v in stats.items():
    print(k, v)
